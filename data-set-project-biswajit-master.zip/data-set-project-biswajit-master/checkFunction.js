const fs = require('fs');
const csv = require('fast-csv');
function getNoOfMatchesPerYear(csvFile){
	return new Promise(function (resolve, reject) {
		let count = 0;
		let objMatchNo = {};
		csvFile
		.pipe(csv())
		.on('data', function(data){
			if(count != 0){
				if(objMatchNo[data[1]] == undefined){
					objMatchNo[data[1]] = 1;
				}
				else{
					objMatchNo[data[1]] = objMatchNo[data[1]] + 1;
				}
			}
			count++;
		})
		.on('end', function(data){
			resolve(objMatchNo);	
		});
	});
}

getNoOfMatchesPerYear(matchCsvFile).then(function(data){
	try{
		console.log(data);
	}
	catch(e){
		console.log("There is an erron");
	}
});
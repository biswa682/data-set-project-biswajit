const expect = require('chai').expect;
const result = require('../src/checkFunction');
const fs = require('fs');
const testWinnerPerYear = fs.createReadStream('testWinnerPerYear.csv', 'utf8');
const deliveriesCsvFile = fs.createReadStream('deliveriesDemo.csv', 'utf8');
const matches2016 = fs.createReadStream('matches16.csv','utf8');
const testExtraRun = fs.createReadStream('testExtraRun2.csv', 'utf8');
const matches2015 = fs.createReadStream('matches15.csv','utf8');
const economicalBowler = fs.createReadStream('economialBowler.csv','utf8');
describe('Checking The list of economical Bowler', function(){
	it("Get the list of Bowler", function(done){
		let expectedOutput = {
			'TS Mills': 8,
			'BCJ Cutting': 5
		}

		result.getEconomicalBowlers(matches2015, economicalBowler, 2).then(function(data){
			try{
				// console.log(data);
				expect(data).deep.equals(expectedOutput);
				done();
			}
			catch(e){
				console.log("There is an error in getEconomicalBowlers method");
				done(e);
			}
		});
	});
});
// describe("Checking the Extra run conceded by each team", function(){
// 	it("Get the extra run per team", function(done){
// 		let expectedOutput = {
// 			'Royal Challengers Bangalore': 10,
// 			'Sunrisers Hyderabad': 12,
// 			'Rising Pune Supergiant': 9
// 		}
// 		result.getExtraRunPerTeam(matches2016, testExtraRun).then(function(data){
// 			try{
// 				expect(data).deep.equals(expectedOutput);
// 				done();
// 			}
// 			catch(e){
// 				done(e);
// 			}
// 		});
// 	});
// });
// describe("Checking the no of matches per year", function(){
// 	it("Get the no of matches per year", function(done){
// 		let expectedOutput = { 
// 	  	'2014': 5,
// 	  	'2015': 5,
// 	  	'2016': 5,
// 	  	'2017': 5 
// 	  }

// 		result.getNoOfMatchesPerYear(testWinnerPerYear).then(function(data){
// 			try{
// 				expect(data).deep.equals(expectedOutput);
// 				done();
// 			}
// 			catch(e){
// 				console.log("There is an error"+e);
// 				done(e);
// 			}
// 		});
// 	});
// });

// describe("No of matches win by per team in per year", function(){
// 	// it("Get the no of rows", function(done){
// 	// 	let expectedOutput = 21;
// 	// 	result.getMatchesOwnByAllTeam(testWinnerPerYear).then(function(data){
// 	// 		try{
// 	// 			console.log(data);
// 	// 			expect(data).not.equals(expectedOutput);
// 	// 			done();
// 	// 		}
// 	// 		catch(e){
// 	// 			console.log("There is an error"+e);
// 	// 			done(e);
// 	// 		}
// 	// 	});
// 	// });
// 	it("Checking testWinnerPerYear csv file", function(done){
// 		let expectedOutput = {
// 			'2017':{
// 				'Sunrisers Hyderabad': 1,
// 				'Rising Pune Supergiant': 1,
// 				'Kolkata Knight Riders': 1,
// 				'Kings XI Punjab': 1,
// 				'Royal Challengers Bangalore': 1
// 			},
// 			'2016':{
// 				'Sunrisers Hyderabad': 1,
// 				'Mumbai Indians': 3,
// 				'Kings XI Punjab': 1
// 			},
// 			'2015':{
// 				'Kolkata Knight Riders': 2,
// 				'Mumbai Indians': 1,
// 				'Delhi Daredevils': 2
// 			},
// 			'2014':{
// 				'Mumbai Indians': 1,
// 				'Kolkata Knight Riders': 2,
// 				'Royal Challengers Bangalore': 2
// 			}
// 		};
// 		result.getMatchesOwnByAllTeam(testWinnerPerYear).then(function(data){
// 			try{
// 				expect(data).deep.equals(expectedOutput);
// 				done();
// 			}
// 			catch(e){
// 				console.log("There is an error"+e);
// 				done(e);
// 			}
// 		});
// 	});
// });
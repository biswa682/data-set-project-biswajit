const express = require('express');
const fs = require('fs');
const csv = require('fast-csv');
const matchCsvFile = fs.createReadStream('./ipl/matches.csv', 'utf8');
const deliveriesCsvFile = fs.createReadStream('./ipl/deliveries.csv', 'utf8');
const operation = require('./src/checkFunction');
const app = express();
app.use(express.static('public'));
app.set('view engine', 'ejs');
let objMatchCountPerYear = {};
let objWinnerTeamPerYear = {};
let objExtraRunPerTeam = {};
let objEconomicalBowler = {};
operation.getNoOfMatchesPerYear(matchCsvFile).then(function(data){
	try{
		objMatchCountPerYear = data;
	}
	catch(e){
		console.log("There is an error in getNoOfMatchesPerYear method");
	}
});
operation.getMatchesOwnByAllTeam(matchCsvFile).then(function(data){
	try{
		objWinnerTeamPerYear = data;
	}
	catch(e){
		console.log("There is an error in getMatchesOwnByAllTeam method");
	}
});
operation.getExtraRunPerTeam(matchCsvFile, deliveriesCsvFile).then(function(data){
	try{
		objExtraRunPerTeam = data;
	}
	catch(e){
		console.log("There is an error in getExtraRunPerTeam method");
	}
});
operation.getEconomicalBowlers(matchCsvFile, deliveriesCsvFile, 2).then(function(data){
	try{
		console.log(data);
		objEconomicalBowler = data;
	}
	catch(e){
		console.log("There is an error in getEconomicalBowlers method");
	}
});
app.get('/',function(req, res){
	res.render('index');
});
app.get('/noOfMatches', function(req, res){
	res.render('noOfMatches', {matchNo : JSON.stringify(objMatchCountPerYear)});
});
app.get('/winnerTeamPerYear', function(req, res){
	res.render('winnerTeamPerYear',{winnerPerYear : JSON.stringify(objWinnerTeamPerYear)});
});
app.get('/extraRunInEachTeam', function(req, res){
	res.send(JSON.stringify(objExtraRunPerTeam));
});
app.get('/economicalBowlers', function(req, res){
	res.send(JSON.stringify(objEconomicalBowler));
});
app.listen(3002, function(){
	console.log("Server is running......");
});